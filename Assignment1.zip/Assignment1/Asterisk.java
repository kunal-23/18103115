import java.util.Scanner; 
import java.util.*;
import java.io.*;
class Asterisk 
{ 
static String substrsor(String para, 
					String word) 
{ 
	String[] word_list = para.split("\\s+");  
	String result = "";  
	String stars = ""; 
	for (int i = 0; i < word.length(); i++) 
		stars += '*'; 
	int index = 0; 
	for (String i : word_list) 
	{ 
		if (i.compareTo(word) == 0) 
			word_list[index] = stars; 
		index++; 
	}  
	for (String i : word_list) 
		result += i + ' '; 

	return result; 
} 


public static void main(String[] args) 
{ 
	 Scanner input = new Scanner(System.in);
        System.out.print("Enter String: ");
        String str = input.nextLine();
        System.out.print("Enter substring:  ");
        String substr=input.nextLine();

	System.out.println(substrsor(str, substr)); 
} 
} 

