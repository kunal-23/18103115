import java.util.Scanner;
public class Count 
{ 

    static final int MAX = 256; 
    static boolean compare(char arr1[], char arr2[]) 

    { 

        for (int i = 0; i < MAX; i++) 
            if (arr1[i] != arr2[i]) 
                return false; 
        return true; 

    }

    static void search(String substr, String str) 

    { 

        int M = substr.length(); 
        int N = str.length(); 
        char[] count1 = new char[MAX]; 
        char[] count2 = new char[MAX]; 
        for (int i = 0; i < M; i++) 
        { 
            (count1[substr.charAt(i)])++; 
            (count2[str.charAt(i)])++; 

        } 
        for (int i = M; i < N; i++) 

        { 
            if (compare(count1, count2)) 
                System.out.println("Found at Index " + (i - M)); 

            (count2[str.charAt(i)])++; 
            count2[str.charAt(i-M)]--; 

        } 

        if (compare(count1, count2)) 
            System.out.println("Found at Index " + (N - M)); 

    } 

    public static void main(String args[]) 

    { 

        Scanner input = new Scanner(System.in);
        System.out.print("Enter String: ");
        String str = input.nextLine();
        System.out.print("Enter substring:  ");
        String substr=input.nextLine();

        search(substr, str); 

    } 
} 