import java.io.*;
import java.util.*;

public class Graph{

    public static void main(String[] args) {
        int V,E;
        Scanner scan = new Scanner(System.in);
            System.out.print("Enter number of Vertices-");
            V = scan.nextInt();
            System.out.print("Enter the number of edges-");
            E = scan.nextInt();

            int graph[][]=new int[E][3];
            System.out.println("Enter the edge and weight as <start end weigth>: ");
            for (int i = 0; i < E; i++)
                for (int j = 0; j < 3; j++)
                    graph[i][j] = scan.nextInt();


        int source=0;
        int []dis = new int[V];
        for (int i = 0; i < V; i++)
            dis[i] = Integer.MAX_VALUE;

        dis[source] = 0;
        for (int i = 0; i < V - 1; i++)
        {

            for (int j = 0; j < E; j++)
            {
                if (dis[graph[j][0]] + graph[j][2] <
                        dis[graph[j][1]])
                    dis[graph[j][1]] =
                            dis[graph[j][0]] + graph[j][2];
            }
        }
        boolean flag=false;
        for (int i = 0; i < E; i++)
        {
            int a = graph[i][0];
            int b = graph[i][1];
            int weight = graph[i][2];
            if (dis[a] != Integer.MAX_VALUE &&
                    dis[a] + weight < dis[b]){
                System.out.println("Negative cycles exist.");
                flag=true;
            }
        }
        if(flag==false){
            System.out.println("dis of other vertices from Source(0): ");
            for (int i = 0; i < V; i++)
                System.out.println("for vertex "+i + "-> " + dis[i]);
        }
    }
}

