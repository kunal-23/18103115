import java.util.Arrays;  
import java.util.Scanner;
   
public class Countingsort {  
    static void sort(int a[], int size) {
        
        int maxi;
        maxi=a[0];
        for(int i=0;i<size;i++){
        	if(a[i]>maxi){
        		maxi=a[i];
        	}
        }
        
        int [] count = new int [maxi+1];
        for(int i=0;i<size;i++){
        	count[a[i]]++;
        }
        
        for(int i=1;i<=maxi;i++){
        	count[i]+=count[i-1];
        }
        int [] sorted = new int [size+1];
        for(int i=size-1;i>=0;i--){
        	sorted[count[a[i]]-1]=a[i];
        	count[a[i]]--;
        }
        for(int i=0;i<size;i++){
        	System.out.println(sorted[i] + " ");
        }
    }

    public static void main(String[] args) { 
        Scanner input = new Scanner(System.in);
        System.out.print("Number of times you want to give input: ");
        int t = input.nextInt();
        while(t!=0){
        	System.out.print("Enter size of array:  ");
        	int size = input.nextInt();
        	int [] a= new int [size];
        	System.out.print("Enter elements:  ");
        	for(int i=0;i<size;i++){
        		a[i]=input.nextInt();
            }
            sort(a,size);
            t--;
        }
       
    }  
}

