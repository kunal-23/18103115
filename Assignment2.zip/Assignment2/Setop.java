import java.io.*;
import java.util.*;

public class Setop{

	public static void intersection_Array(int[] arr1,int[] arr2)
	{
		int count=0;
		for(int i=0;i<arr1.length;i++){
			boolean flag=false;
			for(int j=0;j<arr2.length;j++){
				if(arr1[i]==arr2[j]){
					flag=true;
					break;
				}
			}
			if(flag==true){
				count=1;
				System.out.print(arr1[i]+ " ");
			}
		}
		if(count==0){
			System.out.print("No common element");
		}
	}
	public static void intersection_Set(HashSet<Integer>set1,HashSet<Integer>set2)
	{

		for(Integer i:set1){
			if(set2.contains(i)){
				System.out.print(i+ " ");
			}
		}
	}
	public static void union_Array(int[] arr1,int[] arr2)
	{
		ArrayList<Integer> al = new ArrayList<Integer>(); 	
		for(int i=0;i<arr1.length;i++){
			al.add(arr1[i]);
		}
		for(int i=0;i<arr2.length;i++){
			boolean flag=false;
			for(int j=0;j<arr1.length;j++){
				if(arr1[j]==arr2[i]){
					flag=true;
					break;
				}
			}
			if(flag==false)
				al.add(arr2[i]);
		}
		Collections.sort(al);
		for(int i=0;i<al.size();i++){
			System.out.print(al.get(i)+ " ");
		}
	}
	public static void union_Set(HashSet<Integer>set1,HashSet<Integer>set2)
	{
		ArrayList<Integer> al1 = new ArrayList<Integer>(); 
		for(Integer i:set1){
			al1.add(i);
		}
		for(Integer i:set2){
			if(set1.contains(i))
				continue;
			else
				al1.add(i);
		}
		Collections.sort(al1);
		for(int i=0;i<al1.size();i++){
			System.out.print(al1.get(i)+ " ");
		}

	}
	public static void complement_Array(int[] universal,int[] arr)
	{
		for(int i=0;i<universal.length;i++){
			boolean flag=false;
			for(int j=0;j<arr.length;j++){
				if(universal[i]==arr[j])
				{
					flag=true;
					break;
				}
			}
			if(flag==false)
				System.out.print(universal[i] + " ");
		}
	}
	public static void complement_Set(HashSet<Integer>universal,HashSet<Integer>set)
	{
		for(Integer i:universal)
		{
			if(set.contains(i)==false)
			{
				System.out.print(i + " ");
			}
		}
	}
	public static ArrayList<Integer> removeDuplicate(int[] arr,int n)
	{
		if(n==0)
			return new ArrayList<Integer>();
		ArrayList<Integer>arrl=new ArrayList<Integer>();
		arrl.add(arr[0]);
		for(int i=1;i<n;i++)
		{
			if(arr[i]==arr[i-1])
				continue;
			else
				arrl.add(arr[i]);
		}
		return arrl;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try{
			System.out.println("Universal Set: {0,1,2,3,4,5,6,7,8,9,10} ");
			int[] uniArr=new int[11];
			HashSet<Integer> uniSet=new HashSet<Integer>();
			for(int i=0;i<11;i++)
			{
				uniArr[i]=i;
				uniSet.add(uniArr[i]);
			}
			System.out.print("Enter size of first array: ");
			int n1=sc.nextInt();
			if(n1<0)
			{
				System.out.println("Size can never be negative!");
				return ;
			}
			sc.nextLine();
			int[] arr1=new int[n1];
			HashSet<Integer> set1=new HashSet<Integer>();
			for(int i=0;i<n1;i++)
			{
				System.out.printf("Enter %dth element: ",i);
				arr1[i]=sc.nextInt();
				sc.nextLine();
				if(arr1[i]<0||arr1[i]>10)
				{
					System.out.print("Invalid Input! Input must belongs to univeral set.");
					return ;
				}
				set1.add(arr1[i]);
			}
			HashSet<Integer> set2=new HashSet<Integer>();
			System.out.print("Enter size of second array: ");
			int n2=sc.nextInt();
			if(n2<0)
			{
				System.out.println("Size can never be negative!");
				return ;
			}
			sc.nextLine();
			int[] arr2=new int[n2];
			for(int i=0;i<n2;i++)
			{
				System.out.printf("Enter %dth element: ",i);
				arr2[i]=sc.nextInt();
				sc.nextLine();
				if(arr2[i]<0||arr2[i]>10)
				{
					System.out.print("Invalid Input! Input must belongs to univeral set.");
					return ;
				}
				set2.add(arr2[i]);
			}
			System.out.println();
			System.out.println("Using arrays: ");
			System.out.println();
			long starttime=System.nanoTime();
			Arrays.sort(arr1);
			Arrays.sort(arr2);
			ArrayList<Integer>arrl=removeDuplicate(arr1,n1);
			int s=arrl.size();
			arr1=new int[s];
			int z=0;
			for(Integer i:arrl)
			{
				arr1[z++]=i;
			}
			arrl=removeDuplicate(arr2,n2);
			s=arrl.size();
			arr2=new int[s];
			int zz=0;
			for(Integer i:arrl)
			{
				arr2[zz++]=i;
			}
			System.out.print("Intersection of two Arrays is: ");
			intersection_Array(arr1,arr2);
			System.out.println();
			System.out.print("Union of two Arrays is: ");
			union_Array(arr1,arr2);
			System.out.println();
			System.out.print("Complement of Array1 is: ");
			complement_Array(uniArr,arr1);
			System.out.println();
			System.out.print("Complement of Array2 is: ");
			complement_Array(uniArr,arr2);
			System.out.println();
			long endtime=System.nanoTime();
			System.out.printf("Computation time of computing all above operations using Arrays: %.2f milliseconds.",(double)(endtime-starttime)/1000000.0);
			System.out.println();
			System.out.println();
			System.out.println("Using HashSets (More Efficient): ");
			System.out.println();
			long starttimeset=System.nanoTime();
			System.out.print("Intersection of two HashSets is: ");
			intersection_Set(set1,set2);
			System.out.println();
			System.out.print("Union of two HashSets is: ");
			union_Set(set1,set2);
			System.out.println();
			System.out.print("Complement of HashSet1 is: ");
			complement_Set(uniSet,set1);
			System.out.println();
			System.out.print("Complement of HashSet2 is: ");
			complement_Set(uniSet,set2);
			System.out.println();
			long endtimeset=System.nanoTime();
			System.out.printf("Computation time of computing all above operations using HashSets: %.2f milliseconds.",(double)(endtimeset-starttimeset)/1000000.0);
			System.out.println();
			System.out.println();
		}
		catch(InputMismatchException e)
		{
			System.out.println("You have entered something wrong! Value must be of suitable Datatype.");
		}
	}
}


