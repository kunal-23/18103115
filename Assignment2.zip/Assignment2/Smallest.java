import java.io.*;
import java.util.*;

public class Smallest{

    public static void main(String[] args) {
    	int i=1;
    	int sum=1;
    	int n=Integer.MAX_VALUE;
    	while(i<n){
    		if(sum==i*i){
    			System.out.println("Sum= " + sum + " i= "+ i);
    		}
    		
			i++;
			sum+=i;
    		
    	}
    	System.out.println("Sum= " + sum + " i= "+ i);
    }
}