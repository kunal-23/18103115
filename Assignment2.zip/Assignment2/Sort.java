import java.io.*;
import java.util.*;

public class Sort{

    public static void main(String[] args) {
    	Scanner input = new Scanner(System.in);
        System.out.print("Enter String: ");
        String s = input.nextLine();
        int n;
        n=s.length();
        char a[] = s.toCharArray();
        for(int i=0;i<n;i++){
        	for(int j=i+1;j<n;j++){
        		if(a[i] >a[j] ){
        			char temp;
        			temp=a[i] ;
        			a[i] = a[j] ;
        			a[j] = temp;
        			
        		}
        	}
        }
        for(int i=0;i<n;i++){
        	System.out.print(a[i]);
        }

    }
}