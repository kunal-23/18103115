public class Q2 {
	public static void main(String[] args) {
		int val = -1;
		byte a = (byte)val;
		char b = (char)a;
		int c = (int)b;
		System.out.println(c);
	}
}
/**
EXPLANATION
=> Initially the value of int variable(val) is -1 
   Range of Integer is -2^31 to 2^31-1 so -1 is stored in val variable
   After casting int -> byte and stored it in byte variable(a) (because of Range of byte is -128 to 127)
   -1 is stored in a variable
   Then we cast byte -> char and stored it in char variable(b) Range of char is 0 to 2^16-1 
   As val -1 is out of range  so 2^16-1 is stored in b variable
   And then when we cast again char -> int  and range of Interger is  -2^31 to 2^31-1 
   so 2^16-1 is stored in c and we get output equal to 2^16-1
*/